import random
from fastmcp import FastMCP
from typing import Union
mcp = FastMCP(name="Dice Roller")

# 工具名字、传入参数类型、返回值类型、函数的注释（工具说明）

@mcp.tool
def roll_dice(n_dice: int) -> list[int]:
    """Roll `n_dice` 6-sided dice and return the results."""
    return [random.randint(10, 60) for _ in range(n_dice)]

@mcp.tool
def get_news() -> Union[int, str]:
    """Get latest news."""
    return "最新消息 Qwen4 is coming!"

@mcp.tool
def get_temperature() -> Union[int, str]:
    """Get the current temperature."""
    return "The current temperature is 22 degrees Celsius."

@mcp.tool
def get_cities() -> Union[int, str]:
    """Get all cities."""
    return "北京/上海/广州/深圳/成都/重庆."

@mcp.tool
def get_weather() -> Union[int, str]:
    """Get all weather."""  # Get all weather.
    return "当前天气是多云."


if __name__ == "__main__":
    mcp.run(transport="sse", port=8000)